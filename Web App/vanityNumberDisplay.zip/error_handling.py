import boto3
import json
import logging
import os

class ErrorHandling:
    def __init__(self, exception, ErrorCode, aws_request_id):
        #initializing sqs and sns client, queue url and target arn.
        #sqs queue url and sns arn are stored under configurations -> environment variables
        #SNS target arn is stored under configuration -> environment variables with key 'SNS'
        #Sqs queue url is stored under configuration -> environment variables withkey 'SQS'
        self.sqsClient = boto3.client('sqs')
        self.queueUrl = os.getenv('SQS')
        self.snsClient = boto3.client('sns', region_name = 'us-east-1')
        self.targetArn = os.getenv('SNS')
        self.exception = exception
        self.errorCode = ErrorCode
        self.aws_request_id = aws_request_id

    def _send_error_messages(self):
        #send SQS DLQ error notification message with custom error code and custom error message
        sqs_response = self.sqsClient.send_message(
            QueueUrl=self.queueUrl,
            DelaySeconds = 0,
            MessageAttributes = {
                'ErrorCode':{
                    'DataType':'Number',
                    'StringValue':self.errorCode
                },
                'ErrorMessage':{
                    'DataType':'String',
                    'StringValue':str(self.exception)
                },
                'RequestID':{
                    'DataType':'String',
                    'StringValue': self.aws_request_id
                }
            },
            MessageBody = (
                json.dumps({"message":"Exception"})
            )
        )
        logging.info(sqs_response)

        #send SNS e-mail notification to topic subscribers
        sns_message = {
            'ErrorCode': self.errorCode,
            'ErrorMessage': str(self.exception),
            'RequestID': self.aws_request_id
        }
        response = self.snsClient.publish(
            TargetArn = self.targetArn,
            Message = json.dumps({'default': json.dumps(sns_message, default=str),
                                    'email': sns_message}, default=str),
            Subject = 'Vanity Number Generator Error',
            MessageStructure = 'json'
        )
        logging.info(response)