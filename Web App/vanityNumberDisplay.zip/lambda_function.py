import logging
import boto3
import json
from error_handling import ErrorHandling
from db_connection import DynamoDBConnection

def lambda_handler(event,context):
    """
    This function fetches vanity Generator data from dynamodb table, sort by date and time,
    find the last 5 callers and the vanity numbers generated. 
    Using Amazon Amplify, the date returned from this lambda function will be displayed in the web app.
    """
    try:
        awsRequestId = context.aws_request_id        
        dynamo_db = DynamoDBConnection(awsRequestId)

        #get all callers details from dynamodb table
        all_caller_details = dynamo_db._get_last_five_callers()

        #sort caller details by date and time
        sorted_date = sorted(all_caller_details, key=lambda d: d['LastCallTime'], reverse = True) 
        print(sorted_date)

        #logic to fetch last 5 caller details if available.
        if len(sorted_date)>=5:
            return {
                "statusCode" : 200,
                "body" : json.dumps({"Callers":sorted_date[0:5]})
                }
        else:
            num_callers = len(sorted_date)
            return {
                "statusCode" : 200,
                "body" : json.dumps({"Callers":sorted_date[0:num_callers]})
            }
    
    #error handling
    except Exception as ex:
        errorCode = '403'
        ErrorHandling(ex,errorCode,awsRequestId)._send_error_messages()
        logging.exception(str(ex))
        return {
            'errorCode' : 403,
            'body' : json.dumps({'message' : str(ex)})
        }     


