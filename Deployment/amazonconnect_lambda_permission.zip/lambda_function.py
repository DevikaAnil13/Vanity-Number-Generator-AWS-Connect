import boto3
import os

def lambda_handler(event,context):
    account = os.getenv('AccountID')
    return boto3.client("lambda").add_permission(
        Action = "lambda:InvokeFunction",
        FunctionName = "vanityPhoneNumberGenerator",
        Principal = "connect.amazonaws.com",
        SourceAccount = account,
        StatementId = "1")