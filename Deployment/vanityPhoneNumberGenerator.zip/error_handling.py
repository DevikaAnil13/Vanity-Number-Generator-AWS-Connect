import boto3
import json
import logging
import os

class ErrorHandling:
    def __init__(self, exception, ErrorCode, customerNumber, aws_request_id):
        #initialize sqs and sns clients, target arn and queue url.
        #SNS target arn is stored under configuration -> environment variables with key 'sns_arn'
        #Sqs queue url is stored under configuration -> environment variables withkey 'sqs_url'
        self.sqsClient = boto3.client('sqs')
        self.queueUrl = os.getenv('sqs_url')
        self.snsClient = boto3.client('sns', region_name = 'us-east-1')
        self.targetArn = os.getenv('sns_arn')
        self.exception = exception
        self.errorCode = ErrorCode
        self.aws_request_id = aws_request_id
        self.message = customerNumber

    def _send_error_messages(self):
        #send SQS DLQ error notification message with   
        sqs_response = self.sqsClient.send_message(
            QueueUrl=self.queueUrl,
            DelaySeconds = 0,
            MessageAttributes = {
                'ErrorCode':{
                    'DataType':'Number',
                    'StringValue':self.errorCode
                },
                'ErrorMessage':{
                    'DataType':'String',
                    'StringValue':str(self.exception)
                },
                'RequestID':{
                    'DataType':'String',
                    'StringValue': self.aws_request_id
                }
            },
            MessageBody = (
                json.dumps({"customer Number":self.message})
            )
        )
        logging.info(sqs_response)

        #send SNS e-mail notification and SMS notification to topic subscribers
        sns_message = {
            'ErrorCode': self.errorCode,
            'ErrorMessage': str(self.exception),
            'RequestID': self.aws_request_id
        }
        response = self.snsClient.publish(
            TargetArn = self.targetArn,
            Message = json.dumps({'default': json.dumps(sns_message, default=str),
                                    'email': sns_message}, default=str),
            Subject = 'Vanity Number Generator Error',
            MessageStructure = 'json'
        )
        logging.info(response)