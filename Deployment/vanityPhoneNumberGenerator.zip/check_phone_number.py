#Python script to validate phone number and extract the last 7 numbers

import re
import logging

class CheckPhoneNumber:
    """This class takes the input phone number and performs required operations to validate phone number
        and find the specific formatted codes from phone number"""

    def __init__(self,phoneNumber):
        
        logging.info(f"phone number: {phoneNumber}")
        
        #All UK mobile telephone numbers have 10 national (significant) numbers after the "0" trunk code.
        #if calling from outside UK, 0 is replaced by +44, so it would become +44 7xxx xxxxxx
        #The correct way to write a number is 07xx xxx xxxx for domestic use or +44(0)7xx xxx xxxx
        regex_pattern = re.match("^(((\+44-\s?\d{4}|\(?0-\s?\d{4}\)?)\s?\d{3}\s?\d{3})|((\+44\s?\d{3}|\(?0\d{3}\)?)\s?\d{3}\s?\d{4})|((\+44\s?\d{2}|\(?0\d{2}\)?)\s?\d{4}\s?\d{4}))(\s?\#(\d{4}|\d{3}))?$",phoneNumber)
        
        #remove special characters and spaces from phoneNumber and find the tenDigitcallerNumber, countryCode, 
        #areaCode, phonePrefix and lineNumber for international and domestic numbers.
        logging.info(f"regex pattern:{regex_pattern}")
        self.callerNumber = ''.join(e for e in regex_pattern.group(0) if e.isnumeric())
        logging.info(self.callerNumber)
        
        #find 10 digit caller number 
        self.tenDigitcallerNumber = self.callerNumber[-10:]
        
        #country code is +44 or 0 at index position before 10 digit number
        country_code = self.callerNumber[0:-10]
        if country_code == "44":
            self.countryCode = "+"+str(country_code)
        elif country_code == "0":
            self.countryCode = country_code
        
        #areaCode is last 7 digits of phone number
        self.areaCode = self.tenDigitcallerNumber[:-7]

        #phonePrefix is 4th, 5th and 6th numbers of a 10 digit UK mobile number
        self.phonePrefix = self.tenDigitcallerNumber[-7:-4]
        
        #lineNumber is the last 4 digits of a phone Number
        self.lineNumber = self.tenDigitcallerNumber[-4:]

        #customerNumber is the formatted phone number without any soecial characters and spaces.
        self.customerNumber = str(self.countryCode)+str(self.areaCode)+str(self.phonePrefix)+str(self.lineNumber)

    #function to check if the phone number codes are present or not
    def _is_codes_None(self):
        return (
            self.callerNumber == None or
            self.tenDigitcallerNumber == None or
            self.countryCode == None or
            self.areaCode == None or
            self.phonePrefix == None or
            self.lineNumber == None)
    
    #function to get last seven digits of a mobile number
    def seven_digit_number(self):
        return str(self.phonePrefix + self.lineNumber)