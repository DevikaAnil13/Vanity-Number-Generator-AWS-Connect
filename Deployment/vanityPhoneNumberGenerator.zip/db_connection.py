import boto3
from error_handling import ErrorHandling
import logging
import json
from datetime import datetime
from time import sleep
import os

class DynamoDBConnection:
    def __init__(self,phoneNumber,event,vanity_words,awsRequestId):
        #initialize dynamodb client and resource, tablename and aws_request id for error handling
        self.dynamodbClient = boto3.client('dynamodb', region_name = 'us-east-1')
        self.dynamodbResource = boto3.resource('dynamodb', region_name = 'us-east-1')
        self.phoneNumber = phoneNumber
        self.event = event
        self.vanity_numbers = vanity_words
        self.aws_request_id = awsRequestId
        env = os.getenv('TABLE')
        self.tableName = f"vanity{env}ContactList"

    #check whether the dynamodb table exists. If the table does not exist, create a new table
    #with the specified table name.
    def check_db_connection(self):
        try:
            table = self.dynamodbResource.Table(self.tableName)
            is_table_existing = table.table_status in ("CREATING", "UPDATING", "DELETING", "ACTIVE")
            
            
            #if table is not existing, create a new table
            if not is_table_existing:
                logging.info("Dynamo db table does not exist, creating table..")
                self.create_dbtable()

            else:
                #return the table
                logging.info('Dynamodb Connection Established')
                return table
        
        #error handling for exceptions
        except Exception as ex:
            errorCode = '403'
            ErrorHandling(ex,errorCode,self.event,self.aws_request_id)._send_error_messages()
            logging.exception(str(ex))
            return{
                'errorCode': 403,
                'body' : json.dumps({'message': str(ex)})
            }
    
    #create a dynamodb table with Key and attributes specified
    def create_dbtable(self):
        try:
            self.dynamodbClient.create_table(
                AttributeDefinitions=[
                    {
                        "AttributeName": "PhoneNumber",
                        "AttributeType": "S"
                    }
                ],
                TableName=self.tableName,
                KeySchema=[
                    {
                        "AttributeName": "PhoneNumber",
                        "KeyType": "HASH"
                    }
                ],
                ProvisionedThroughput={
                    "ReadCapacityUnits": 10,
                    "WriteCapacityUnits": 10
                }
            )
            #Wait for the table to get created.
            waiter = self.dynamodbClient.get_waiter("table_exists")
            waiter.wait(TableName=self.tableName)
        
        #error handling for exceptions in creating dynamodb table
        except Exception as ex:
            errorCode = '403'
            ErrorHandling(ex,errorCode,self.event,self.aws_request_id)._send_error_messages()
            logging.exception(str(ex))
            return {
                'errorCode' : 403,
                'body' : json.dumps({'message' : str(ex)})
            }

    #upload generated vanity numbers to dynamodb table
    def upload_to_db(self):
        try:

            #check dynamodb connection and cfeate table if table do not exist
            table = self.check_db_connection()
            logging.info(self.event)

            #put the items to dynamodb table
            response = table.put_item(Item={
                'PhoneNumber' : self.phoneNumber,
                'LastCallTime' : datetime.now().strftime('%Y/%m/%d %H:%M:%S'),
                'VanityNumber1' : self.vanity_numbers[0],
                'VanityNumber2' : self.vanity_numbers[1],
                'VanityNumber3' : self.vanity_numbers[2],
                'VanityNumber4' : self.vanity_numbers[3],
                'VanityNumber5' : self.vanity_numbers[4]
            })
            logging.info(str(response))
        
        #error handling for saving data to dynamodb
        except Exception as ex:
            errorCode = '403'
            ErrorHandling(ex,errorCode,self.event,self.aws_request_id)._send_error_messages()
            logging.exception(str(ex))
            return {
                'errorCode' : 403,
                'body' : json.dumps({'message' : str(ex)})
            }
    
    #fetch existing vanity numbers generated and stores in dynamodb for a phone number
    def _get_existing_vanity_number(self):
        
        #check the dynamodb connection and create a table if not existing
        self.check_db_connection()
        dynamodb_response = self.dynamodbClient.get_item(
            TableName=self.tableName,
            Key={
                "PhoneNumber": {
                    "S" : self.phoneNumber
                }
            },
            AttributesToGet=[
                "VanityNumber1", "VanityNumber2", "VanityNumber3", "VanityNumber4", "VanityNumber5"
            ]
        )

        vanityNumbers = {}

        #fetch the details corresponding to phone number and return as a list
        if "Item" in dynamodb_response:
            vanity_number = dynamodb_response["Item"]
            vanityNumbers = [
                vanity_number["VanityNumber1"]["S"] if "VanityNumber1" in vanity_number else None,
                vanity_number["VanityNumber2"]["S"] if "VanityNumber2" in vanity_number else None,
                vanity_number["VanityNumber3"]["S"] if "VanityNumber3" in vanity_number else None
            ]
        return vanityNumbers
    
    # update the date and time of a particular entry if the entry is already present in the dynamodb table.
    # to fetch the last 5 users, date and time needs to be updated if the caller is making 
    # multiple calls to generate vanity number.
    def update_existing_entry(self):
        try:
            dynamodb = boto3.resource('dynamodb')
    
            table = dynamodb.Table(self.tableName)
            
            #update currentDateTime attribute corresponding to the input phone number
            update_response = self.dynamodbClient.update_item(
                TableName = self.tableName,
                Key={
                        "PhoneNumber": {
                    "S" : self.phoneNumber
                    }
                },
                UpdateExpression="set LastCallTime = :currentDateTime",
                ExpressionAttributeValues={
                        ':currentDateTime': {
                            "S" : datetime.now().strftime('%Y/%m/%d %H:%M:%S')}
                    },
                ReturnValues="UPDATED_NEW"
                )
            
            sleep(2)
            #a sleep is provided to ensure the table gets updated.
            return update_response

        #error handling for updating dynamo db table.    
        except Exception as ex:
            errorCode = '403'
            ErrorHandling(ex,errorCode,self.event,self.aws_request_id)._send_error_messages()
            logging.exception(str(ex))
            return {
                'errorCode' : 403,
                'body' : json.dumps({'message' : str(ex)})
            }

