import os
import json
import re
import logging

#from nltk.corpus import brown, names, reuters, gutenberg
#from nltk.corpus import wordnet as wn

def generate_nltk_words_file():

    #list to add all unique words from each corpus considered
    word_list = []

    #get words from brown corpus of nltk
    wordlist_brown = [word.lower() for word in set(brown.words()) if (word.isalpha() and 2<=len(word)<=7)]
    logging.info(f"unique brown corpus words: {len(wordlist_brown)}")
    word_list.extend(wordlist_brown)

    #get words from wordnet corpus of nltk
    wordnet_words = [word.lower() for word in set(wn.words()) if (word.isalpha() and 2<=len(word)<=7)]
    logging.info(f"unique wordnet corpus words: {len(wordnet_words)}")
    word_list.extend(wordnet_words)

    #get words from names corpus nltk
    names_wordlist = [word.lower() for word in set(names.words()) if (word.isalpha() and 2<=len(word)<=7)]
    logging.info(f"unique names corpus words: {len(names_wordlist)}")
    word_list.extend(names_wordlist)

    #get words from reuters corpus nltk
    reuters_wordlist = []
    for fid in reuters.fileids():
        for word in reuters.words(fid):
            if (word.isalpha() and 2<=len(word)<=7):
                reuters_wordlist.append(word.lower())
    word_list.extend(reuters_wordlist)
    logging.info(f"unique reuters corpus words: {len(set(reuters_wordlist))}")

    #get words from gutenberg corpus nltk
    gutenberg_wordlist = []
    for file_ids in gutenberg.fileids():
        for word_ in gutenberg.words(file_ids):
            if(word_.isalpha() and 2<=len(word_)<=7):
                gutenberg_wordlist.append(word_.lower())
    word_list.extend(gutenberg_wordlist)
    logging.info(f"unique gutenberg corpus words: {len(set(gutenberg_wordlist))}")


    logging.info(f"no. of words including repetitions: {len(word_list)}")


    wordlist = [t for t in set(word_list) if re.match(r'[^\W\d]*$', t)]
    wordlist_filtered = []
    
    #filter and remove words with unicode and special characters
    for words in wordlist:
        count=0
        dic = ["æ","á","é","è","í","ó","ú","ü"]
        for l in dic:
            if l in words:
                count = 1
        if count ==0:
            wordlist_filtered.append(words)
    


    logging.info(f"total unique words from combined corpus sets: {len(wordlist)}")
    wordlist_json = json.dumps({"words":wordlist_filtered})
    jsonFile = open("nltk_words_list.json","w")
    jsonFile.write(wordlist_json)
    jsonFile.close()

def generate_number_map():
    """ Loops through every word in the word list and
        converts letters to phone dial pad digits. The digits are
        used as dictionary keys and the value is a list of all words with the same
        digit conversions. In this way we can have O(1) access to meaningful,
        common words associated with any or all number sequences in a phone number.
    """

    logging.info("working...")
    alpha_num_dict = {
        'a': '2', 'b': '2', 'c': '2',\
        'd': '3', 'e': '3', 'f': '3',\
        'g': '4', 'h': '4', 'i': '4',\
        'j': '5', 'k': '5', 'l': '5',\
        'm': '6', 'n': '6', 'o': '6',\
        'p': '7', 'q': '7', 'r': '7', 's': '7',\
        't': '8', 'u': '8', 'v': '8',\
        'w': '9', 'x': '9', 'y': '9', 'z': '9'
    }

    #generate a word file with all unique corpus words
    generate_nltk_words_file()

    #load word list file and loads the list of unique words, map the words with numbers.
    with open("nltk_words_list.json", "r") as file:
        word_list = json.load(file)

        number_map = {}
        for word in word_list['words']:
            word_number = ""
        
            for letter in word:
                word_number += alpha_num_dict[letter]

            if word_number not in number_map:
                number_map[word_number] = []

            number_map[word_number].append(word.upper())

    with open("number_map.json", "w") as outfile:
        json.dump(number_map, outfile)

    logging.info("done number mapping.")