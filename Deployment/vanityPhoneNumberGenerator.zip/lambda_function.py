#Lambda function to convert phone numbers to vanity numbers,
#save best resulting 5 vanity numbers to dynamodb table,
#send best 3 vanity numbers to the amazon connect user.

import logging
import boto3
import json
from check_phone_number import CheckPhoneNumber
from error_handling import ErrorHandling
from db_connection import DynamoDBConnection
import get_nltk_wordlist
import construct_response_message


#generates number map and save as json if number map does not exist
def get_number_map():
    try:
        with open("number_map.json", "r", encoding="utf8") as file:
            vanity_words = json.load(file)
        return vanity_words
    except Exception as ex:
        logging.info(ex)
        get_nltk_wordlist.generate_number_map()

#function to fetch vanity words from number map
def get_vanity_words(seven_digit_Num,num_word_map):
    vanitywordGroups = []

    #generates vanity words for last 7 numbers, with 2 to 7 alphabets long vanity words
    twoLetterWords = {}
    threeLetterWords = {}
    fourLetterWords = {}
    fiveLetterWords = {}
    sixLetterWords = {}
    sevenLetterWords = {}

    if seven_digit_Num in num_word_map:
        sevenLetterWords[0] = num_word_map[seven_digit_Num]
    
    #loop for last 7 numbers and generating vanity words corresponding to the order
    #in which number occur in phone number.
    for num_len in range(0,7):
        
        #find any two letter matching words
        if num_len<=5:
            key = seven_digit_Num[num_len:num_len+2]

            if key in num_word_map:
                twoLetterWords[key] = num_word_map[key]

        #find any three letter matching words
        if num_len<=4:
            key = seven_digit_Num[num_len:num_len+3]

            if key in num_word_map:
                threeLetterWords[key] = num_word_map[key]
        
        #find any four letter matching words
        if num_len<=3:
            key = seven_digit_Num[num_len:num_len+4]

            if key in num_word_map:
                fourLetterWords[key] = num_word_map[key]
        
        #find any five letter matching words
        if num_len<=2:
            key = seven_digit_Num[num_len:num_len+5]

            if key in num_word_map:
                fiveLetterWords[key] = num_word_map[key]
        
        #find any six letter matching words
        if num_len<=1:
            key = seven_digit_Num[num_len:num_len+6]

            if key in num_word_map:
                sixLetterWords[key] = num_word_map[key]
    
    #generate the list of vanity words and returns it
    vanitywordGroups.extend([
        sevenLetterWords,
        sixLetterWords,
        fiveLetterWords,
        fourLetterWords,
        threeLetterWords
        ])
    
    return vanitywordGroups

def get_vanity_ranks(word_group,countryCode,areaCode,seven_digit_Num,num_word_map):
    """ Generated vanity number word group is taken as input and returns the vanity numbers ranked
        based on the longest vanity words available for the phone numbers last seven digits.
    
        Vanity numbers are returned in the form: countryCode+areaCode+vanityNumber (eg: +44xxxxxxxxxx, 074xxxxxxxx)
        If there are less than five vanity numbers, random letters (per digit) will be assigned
        to make up the difference.
    """

    vanity_word_rankings = []

    #check for each word in the word group of vanity words generated
    for words in word_group:
        if len(words.keys()) != 0:
            for index, word_list in words.items():
                #loop through the vanity words and replace the corresponding digits with the vanity word.
                for word in word_list:
                    vanity_number = seven_digit_Num.replace(index,word)
                    logging.info(f"vanity number: {vanity_number}")

                    vanity_word_rankings.append(vanity_number)
    logging.info(f"vanity_word_rankings: {vanity_word_rankings}")

    # Handles cases where there aren't enough matches for vanity_word_rankings
    next_number = ""
    level = 0


    #check for minimum of 5 vanity number rankings and append original phone numbers if needed.
    while len(vanity_word_rankings) < 5:
        for num in seven_digit_Num:
            if (num in num_word_map and level < len(num_word_map[num])):
                next_number += num_word_map[num][level]
            else:
                next_number += num # Fail safe. Ensures if no letters, the original number is returned.

        if level >= 4:
            level = 0
        else: 
            level += 1

        vanity_word_rankings.append(next_number)
        next_number = ""

    return [f"{countryCode} {areaCode} {''.join(word)}" for word in vanity_word_rankings]



def lambda_handler(event,context):
    """
    This function takes in the call details of the incoming amazon connect call,
    checks for existing data if present in dynamodb table,
    fetches vanity Generator data from dynamodb table, sort by date and time.
    """

    awsRequestId = context.aws_request_id
    #get the call details from event
    customerNumber = str(event\
                    .get("Details",{})\
                    .get("ContactData",{})\
                    .get("CustomerEndpoint",{})\
                    .get("Address",None))
    if not customerNumber:
        raise("JSON object is invalid")
    logging.info(f"Customer number: {customerNumber}")
    
    #customerNumber = event["Details"]["ContactData"]["CustomerEndpoint"]["Address"]
    logging.info(f'Find vanity number for {customerNumber}')

    #validate phone number for UK mobile number format   
    phoneNumber = CheckPhoneNumber(customerNumber)
    
    #error handling for invalid phone number details
    if (phoneNumber == None or phoneNumber._is_codes_None()):
        ex = "Invalid phone number exception"
        errorCode = "400"
        ErrorHandling(ex,errorCode,customerNumber,awsRequestId)._send_error_messages()
        logging.exception(str(ex))
        raise Exception (ex)


    else:
        customerNumber = phoneNumber.customerNumber
        vanity_words = []
        dynamo_db = DynamoDBConnection(customerNumber,event,vanity_words,awsRequestId)
        #check dynamodb table to find any existing records for the phone number
        vanityNumbers = dynamo_db._get_existing_vanity_number()
        if (vanityNumbers is [] or len(vanityNumbers)<3):
            
            #Generate Vanity Numbers for the user
            logging.info("Generating vanity numbers")
            
            #get the number map for unique words
            num_word_map = get_number_map()
            seven_digit_Num = phoneNumber.seven_digit_number()

            #Generate vanity words from number map
            word_group = get_vanity_words(seven_digit_Num,num_word_map)
            logging.info(f"word_group:{word_group}")

            #Rank the vanity words and generate vanity numbers based on ranking
            ranked_words = get_vanity_ranks(word_group,phoneNumber.countryCode,phoneNumber.areaCode,seven_digit_Num,num_word_map)
            logging.info(f"ranked_words:{ranked_words}")
            
            #get top 5 ranked vanity Numbers and store in dynamodb Table
            if len(ranked_words)>=5:
                vanityNumbers= ranked_words[0:5]
                vanityNumbers_out = ranked_words[0:3]
                logging.info(vanityNumbers)
            dynamo_db = DynamoDBConnection(customerNumber, event, vanityNumbers, awsRequestId)
            response = dynamo_db.upload_to_db()
            logging.info(response)
        else:
            dynamo_db.update_existing_entry()
            logging.info(f"vanity number values: {vanityNumbers}")
            vanityNumbers_out = vanityNumbers
        response_message = construct_response_message.get_response_message(vanityNumbers_out)
        return { "Response": response_message}


